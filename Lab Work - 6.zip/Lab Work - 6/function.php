<!DOCTYPE html>
<html>
<head>
    <title>PHP String Functions</title>
</head>
<body>

<?php
$str = "Hello World Welcome to PHP";

echo "<h2>Original String:</h2> $str <br><br>";

// 1) strlen()
echo "<b>1. strlen():</b> " . strlen($str) . "<br><br>";

// 2) strpos()
echo "<b>2. strpos() (Find 'World'):</b> " . strpos($str, "World") . "<br><br>";

// 3) str_word_count()
echo "<b>3. str_word_count():</b> " . str_word_count($str) . "<br><br>";

// 4) strrev()
echo "<b>4. strrev():</b> " . strrev($str) . "<br><br>";

// 5) strtolower()
echo "<b>5. strtolower():</b> " . strtolower($str) . "<br><br>";

// 6) strtoupper()
echo "<b>6. strtoupper():</b> " . strtoupper($str) . "<br><br>";
?>

</body>
</html>