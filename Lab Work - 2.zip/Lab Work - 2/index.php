<?php
// 1. Create a function named collegeInfo()
function collegeInfo() {
    echo "=== College Information ===\n";
    echo "College Name: XYZ Institute of Technology\n";
    echo "Course Name: Computer Applications\n";
    echo "Academic Year: 2025-2026\n\n";
}

// 2. Create a function named studentDetails()
function studentDetails($studentName, $enrollmentNumber, $semester) {
    echo "=== Student Details ===\n";
    echo "Student Name: " . $studentName . "\n";
    echo "Enrollment Number: " . $enrollmentNumber . "\n";
    echo "Semester: " . $semester . "\n\n";
}

// 3. Create a function named calculatePercentage()
function calculatePercentage($marks1, $marks2, $marks3, $marks4, $marks5) {
    $totalMarks = $marks1 + $marks2 + $marks3 + $marks4 + $marks5;
    // Assuming each subject is out of 100
    $percentage = ($totalMarks / 500) * 100;
    
    echo "=== Marks & Percentage ===\n";
    echo "Total Marks Obtained: " . $totalMarks . " / 500\n";
    return $percentage;
}

// 4. Create a function named welcomeStudent()
function welcomeStudent() {
    echo "Welcome to the Student Portal! Wishing you a great academic year.\n";
}


// --- EXECUTION & VERIFICATION ---

// Calling function 1
collegeInfo();

// Calling function 2 with dummy data
studentDetails("Harshit Raiyani", "EN12345678", "4th Semester");

// Calling function 3 and displaying returned percentage
$resultPercentage = calculatePercentage(85, 90, 78, 88, 92);
echo "Percentage: " . $resultPercentage . "%\n\n";

// 4. Verify whether welcomeStudent() function exists before calling it
echo "=== Function Existence Verification ===\n";
if (function_exists('welcomeStudent')) {
    welcomeStudent();
} else {
    echo "Error: The function 'welcomeStudent' does not exist.\n";
}
?>