<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $a=20;
        $b=10;

        echo "Addition = ".($a+$b);
        echo "</br>";
        echo "Subtraction = ".($a-$b);
        echo "</br>";
        echo "Multiplication = ".($a*$b);
        echo "</br>";
        echo "Division = ".($a/$b);
        echo "</br>";
    ?>
</body>
</html>