<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $month = date("F");

        echo "Current Month: " . $month ."<br><br>";
        if ($month == "january")
        {
            echo "Month is january<br>";
        }
        else
        {
            echo "Month is not january<br>";
        }
        switch($month)
        {
            case "june":
                echo "Current Month is june";
                break;
            
            case "july":
                echo "Current Month is july";
                break;
            
            default:
                echo "Another Month";
        }
    ?>
</body>
</html>