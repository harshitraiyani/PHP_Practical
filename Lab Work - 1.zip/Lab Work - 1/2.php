<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $a=25;
        $b=40;
        $c=15;
        $max = max($a,$b,$c);
        $min = min($a,$b,$c);
        echo "Maximum Number = ".$max . "<br>";
        echo "Minimum Number = ".$min; 
    ?>
</body>
</html>