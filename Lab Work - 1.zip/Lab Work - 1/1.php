<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        define("College_Name", "Marwadi University");

        $studentName = "Harshit";
        $semester = "Semester 4";
        $cgpa = 6.25;

        echo "<h3>Previous Semester Result</h3>";
        echo "College Name: " . College_Name . "<br>";
        echo "Student Name: " . $studentName . "<br>";
        echo "Semester: " . $semester . "<br>";
        echo "CGPA: " . $cgpa . "<br>";
    ?>
</body>
</html>