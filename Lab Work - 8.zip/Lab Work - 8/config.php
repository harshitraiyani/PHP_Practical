<?php

$conn = mysqli_connect("localhost", "root", "raiyani_7272", "user_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>