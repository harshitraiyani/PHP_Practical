function validateForm(event) {
    event.preventDefault(); // Form reload hone se rokne ke liye

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const errorMsg = document.getElementById('errorMsg');

    // Simple Validation Check
    if (username === "" || password === "") {
        errorMsg.innerText = "Please fill in all fields.";
        return false;
    }

    if (password.length < 6) {
        errorMsg.innerText = "Password must be at least 6 characters long.";
        return false;
    }

    // Agar sab sahi hai to dummy success alert
    errorMsg.style.color = "#2ecc71";
    errorMsg.innerText = "Login Successful!";
    alert("Welcome back, " + username + "!");
    
    // Yahan aap form submit kar sakte hain
    return true;
}
