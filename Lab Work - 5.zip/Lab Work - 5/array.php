<?php
    $arr = array("Apple", "Banana", "Mango", "Orange");

    echo "Array Elements:<br>";

    foreach($arr as $value)
    {
        echo $value . "<br>";
    }

    echo "<br>";

    $reverse = array_reverse($arr);
    echo "Reversed Array:<br>";
    foreach($reverse as $value)
    {
        echo $value . "<br>";
    }

    echo "<br>";

    $arr1 = array("Apple", "Banana");
    $arr2 = array("Mango", "Orange");

    $result = array_merge($arr1, $arr2);
    echo "Merged Array:<br>";
    foreach($result as $value)
    {
        echo $value . "<br>";
    }
?>