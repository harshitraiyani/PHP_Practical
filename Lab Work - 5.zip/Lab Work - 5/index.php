<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <h1>Welcome</h1>
    <form method="get" action="process.php">
        What's the password? <input type="text" name="password" /><br/>
        <input type="submit" value="ok, send it!" />
    </form>
</body>
</html>